# Preparing for Publications

<aside>
💡 In preparing for publications (e.g., books, journals, magazines), it is important for us to do a thorough check of all the materials. This process includes variety of tasks such as below.

</aside>

[Reference Checking](Preparing%20for%20Publications%20ca1cddc7a761438099b5bebc82d1f87c/Reference%20Checking%209b013553f325409d833cd9f3c66c0bed.md)

[Proofreading](Preparing%20for%20Publications%20ca1cddc7a761438099b5bebc82d1f87c/Proofreading%206ffd5f5fbe72459c9f438cabad2b29f8.md)

[Questionnaire Data Checking](Preparing%20for%20Publications%20ca1cddc7a761438099b5bebc82d1f87c/Questionnaire%20Data%20Checking%2099c8441644ca4f8badb3a3ebbe8da706.md)

[Questionnaire Word Checking](Preparing%20for%20Publications%20ca1cddc7a761438099b5bebc82d1f87c/Questionnaire%20Word%20Checking%208d1e46e3341943c78817abd6335631b3.md)